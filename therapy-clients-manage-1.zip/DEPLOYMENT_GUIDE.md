# Deployment Guide for Unmesh Counseling App

## Play Store Deployment

### Prerequisites
1. Android Studio installed
2. Java Development Kit (JDK) 11 or higher
3. Google Play Console account
4. Signing key for app

### Build Steps

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Build the web app:**
   ```bash
   npm run build
   ```

3. **Sync with Capacitor:**
   ```bash
   npx cap sync android
   ```

4. **Open in Android Studio:**
   ```bash
   npx cap open android
   ```

5. **Generate signed APK/AAB:**
   - In Android Studio: Build > Generate Signed Bundle/APK
   - Choose Android App Bundle (AAB) for Play Store
   - Use your signing key

6. **Upload to Play Store:**
   - Go to Google Play Console
   - Create new app or update existing
   - Upload the AAB file
   - Fill in app details, screenshots, descriptions
   - Submit for review

## Website Deployment

### Option 1: Vercel (Recommended)
1. Connect GitHub repository to Vercel
2. Deploy automatically on push
3. Custom domain: Configure in Vercel dashboard

### Option 2: Netlify
1. Connect GitHub repository to Netlify
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Custom domain: Configure in Netlify dashboard

### Option 3: Firebase Hosting
1. Install Firebase CLI: `npm install -g firebase-tools`
2. Login: `firebase login`
3. Initialize: `firebase init hosting`
4. Deploy: `firebase deploy`

## Google Sheets Integration Setup

### 1. Create Google Sheet
1. Create a new Google Sheet
2. Add headers in first row:
   - Timestamp, Name, Email, Phone, Counselor, Date, Time, Issue Type, Message
3. Note the Sheet ID from URL

### 2. Enable Google Sheets API
1. Go to Google Cloud Console
2. Create new project or select existing
3. Enable Google Sheets API
4. Create API key
5. Restrict API key to Sheets API only

### 3. Configure Supabase Environment
1. Go to Supabase Dashboard
2. Navigate to Edge Functions
3. Set environment variables:
   - `GOOGLE_SHEET_ID`: Your sheet ID
   - `GOOGLE_API_KEY`: Your API key

## Domain Setup

### Recommended Domains
- unmeshcounseling.com
- unmeshcounseling.in
- counselingunmesh.com

### DNS Configuration
1. Purchase domain from registrar (GoDaddy, Namecheap, etc.)
2. Point DNS to your hosting provider:
   - Vercel: Add CNAME record
   - Netlify: Add CNAME record
   - Firebase: Add A records

## App Store Information

### App Details
- **App Name:** उन्मेष - Unmesh Counseling
- **Package ID:** com.unmesh.counseling
- **Category:** Health & Fitness / Medical
- **Target Audience:** 13+ years

### Required Assets
- App icon (512x512, 1024x1024)
- Screenshots (phone and tablet)
- Feature graphic (1024x500)
- Privacy policy URL
- Terms of service URL

### App Description (Hindi/English)
**Hindi:**
उन्मेष काउंसलिंग - आपके मानसिक स्वास्थ्य का साथी। विशेषज्ञ मनोवैज्ञानिकों से ऑनलाइन और ऑफलाइन परामर्श प्राप्त करें।

**English:**
Unmesh Counseling - Your mental health companion. Get online and offline counseling from expert psychologists.

## Security Considerations

1. **API Keys:** Never expose API keys in client code
2. **Database:** Use Row Level Security (RLS) in Supabase
3. **HTTPS:** Ensure all connections use HTTPS
4. **Data Privacy:** Implement proper data handling policies

## Monitoring & Analytics

1. **Google Analytics:** Add tracking code
2. **Supabase Analytics:** Monitor database usage
3. **Error Tracking:** Consider Sentry integration
4. **Performance:** Monitor app performance metrics

## Support & Maintenance

1. **Regular Updates:** Keep dependencies updated
2. **Backup:** Regular database backups
3. **Monitoring:** Set up alerts for downtime
4. **User Feedback:** Monitor app store reviews

For technical support, contact: unmesh.counseling@gmail.com