import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Upload, Edit, Save, X, FileText, Download } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface CVData {
  id?: string;
  fileName: string;
  fileUrl: string;
  counselorName: string;
  uploadedAt: string;
}

interface CVUploadManagerProps {
  counselorName: string;
  onCVSaved?: (cvData: CVData) => void;
}

const CVUploadManager: React.FC<CVUploadManagerProps> = ({ counselorName, onCVSaved }) => {
  const [cvData, setCvData] = useState<CVData | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadExistingCV();
  }, [counselorName]);

  const loadExistingCV = async () => {
    try {
      const { data, error } = await supabase
        .from('cv_uploads')
        .select('id, counselor_name, file_name, file_url, uploaded_at')
        .eq('counselor_name', counselorName)
        .single();

      if (data && !error) {
        setCvData({
          id: data.id,
          fileName: data.file_name,
          fileUrl: data.file_url,
          counselorName: data.counselor_name,
          uploadedAt: data.uploaded_at
        });
      }
    } catch (error) {
      console.log('No existing CV found');
    }
  };

  const uploadFile = async (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'Error',
        description: 'File size must be less than 5MB',
        variant: 'destructive'
      });
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `cv-${counselorName}-${Date.now()}.${fileExt}`;
      const filePath = `cvs/${fileName}`;

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('documents')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('documents')
        .getPublicUrl(filePath);

      const newCvData: CVData = {
        fileName: file.name,
        fileUrl: urlData.publicUrl,
        counselorName,
        uploadedAt: new Date().toISOString()
      };

      await saveCVData(newCvData);
      setCvData(newCvData);
      setIsEditing(false);
      
      toast({
        title: 'Success',
        description: 'CV uploaded and saved successfully'
      });

      if (onCVSaved) onCVSaved(newCvData);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to upload CV',
        variant: 'destructive'
      });
    } finally {
      setUploading(false);
    }
  };

  const saveCVData = async (data: CVData) => {
    const cvRecord = {
      counselor_name: data.counselorName,
      file_name: data.fileName,
      file_url: data.fileUrl,
      uploaded_at: data.uploadedAt
    };

    const { error } = await supabase
      .from('cv_uploads')
      .upsert(cvRecord, {
        onConflict: 'counselor_name'
      });

    if (error) {
      console.error('Database error:', error);
      throw error;
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) uploadFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) uploadFile(file);
  };

  const handleDownload = () => {
    if (cvData?.fileUrl) {
      window.open(cvData.fileUrl, '_blank');
    }
  };

  if (cvData && !isEditing) {
    return (
      <Card className="border-green-200">
        <CardHeader className="bg-green-50">
          <CardTitle className="text-green-800 text-sm flex items-center">
            <FileText className="h-4 w-4 mr-2" />
            CV Saved
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
              <span className="text-sm font-medium">{cvData.fileName}</span>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleDownload}
                className="h-6 w-6 p-0"
              >
                <Download className="h-3 w-3" />
              </Button>
            </div>
            <Button
              onClick={() => setIsEditing(true)}
              variant="outline"
              className="w-full"
              size="sm"
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit CV
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm flex items-center">
          <Upload className="h-4 w-4 mr-2" />
          {cvData ? 'Update CV' : 'Upload CV'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div
            className={`border-2 border-dashed rounded-lg p-4 text-center transition-colors ${
              dragOver ? 'border-orange-400 bg-orange-50' : 'border-gray-300'
            }`}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
          >
            <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
            <p className="text-sm text-gray-600 mb-2">
              Drop CV here or click to browse
            </p>
            <Input
              type="file"
              accept=".pdf,.doc,.docx"
              onChange={handleFileSelect}
              disabled={uploading}
              className="hidden"
              id="cv-upload"
            />
            <Label htmlFor="cv-upload" className="cursor-pointer">
              <Button
                type="button"
                variant="outline"
                disabled={uploading}
                className="pointer-events-none"
              >
                {uploading ? 'Uploading...' : 'Choose File'}
              </Button>
            </Label>
          </div>
          
          {isEditing && (
            <div className="flex space-x-2">
              <Button
                onClick={() => setIsEditing(false)}
                variant="outline"
                size="sm"
                className="flex-1"
              >
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CVUploadManager;