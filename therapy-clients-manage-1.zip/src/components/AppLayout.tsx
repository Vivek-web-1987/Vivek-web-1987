import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';
import Header from './Header';
import Sidebar from './Sidebar';
import HomeSection from './sections/HomeSection';
import CounselorsSection from './sections/CounselorsSection';
import ServicesSection from './sections/ServicesSection';
import AppointmentSection from './sections/AppointmentSection';
import ContactSection from './sections/ContactSection';
import FeedbackSection from './sections/FeedbackSection';

const AppLayout: React.FC = () => {
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const isMobile = useIsMobile();
  const [currentSection, setCurrentSection] = useState('home');

  const renderSection = () => {
    switch (currentSection) {
      case 'home':
        return <HomeSection onSectionChange={setCurrentSection} />;
      case 'counselors':
        return <CounselorsSection onSectionChange={setCurrentSection} />;
      case 'services':
        return <ServicesSection onSectionChange={setCurrentSection} />;
      case 'appointment':
        return <AppointmentSection />;
      case 'contact':
        return <ContactSection />;
      case 'feedback':
        return <FeedbackSection />;
      default:
        return <HomeSection onSectionChange={setCurrentSection} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onMenuClick={toggleSidebar} />
      
      <div className="flex">
        <Sidebar 
          isOpen={sidebarOpen} 
          onClose={toggleSidebar}
          currentSection={currentSection}
          onSectionChange={setCurrentSection}
        />
        
        <main className="flex-1 p-4 md:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {renderSection()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default AppLayout;