import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Clock, Phone, Mail } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

const AppointmentSection: React.FC = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    counselor: '',
    service: '',
    mode: '',
    date: '',
    time: '',
    message: ''
  });

  const validateForm = () => {
    const required = ['name', 'phone', 'counselor', 'service', 'mode', 'date', 'time'];
    for (const field of required) {
      if (!formData[field as keyof typeof formData]) {
        toast({
          title: "त्रुटि!",
          description: `कृपया ${field} भरें।`,
          variant: "destructive"
        });
        return false;
      }
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);

    try {
      const appointmentData = {
        name: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        counselor: formData.counselor,
        date: formData.date,
        time: formData.time,
        issue_type: formData.service,
        message: formData.message.trim(),
        mode: formData.mode
      };

      const { data, error } = await supabase
        .from('appointments')
        .insert(appointmentData)
        .select();

      if (error) {
        console.error('Database error:', error);
        throw new Error(`Database error: ${error.message}`);
      }

      if (!data || data.length === 0) {
        throw new Error('No data returned from insert');
      }

      toast({
        title: "सफल!",
        description: "आपकी अपॉइंटमेंट सफलतापूर्वक बुक हो गई है। हम जल्द ही आपसे संपर्क करेंगे।",
      });
      
      setFormData({
        name: '', phone: '', email: '', counselor: '', service: '', mode: '', date: '', time: '', message: ''
      });
    } catch (error) {
      console.error('Error saving appointment:', error);
      toast({
        title: "त्रुटि!",
        description: "अपॉइंटमेंट बुक करने में समस्या हुई। कृपया पुनः प्रयास करें।",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const counselors = [
    'डॉ. विवेक कुमार शाही',
    'डॉ. तुलिका पांडेय',
    'डॉ. क्षमा सिंह',
    'डॉ. वेंकट रमन पांडेय',
    'डॉ. बिमलेश कुशवाहा',
    'डॉ. अपर्णा पाठक',
    'डॉ. विकास रंजन मणि त्रिपाठी',
    'डॉ. विनोद कुमार गुप्ता'
  ];

  const services = [
    'व्यक्तिगत काउंसलिंग',
    'समूहिक थेरेपी',
    'भावनात्मक बुद्धिमत्ता प्रशिक्षण',
    'छात्र काउंसलिंग',
    'मोबाइल एडिक्शन',
    'गेम एडिक्शन',
    'पेरेंटिंग काउंसलिंग'
  ];

  const timeSlots = [
    '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM', '6:00 PM'
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-orange-800 mb-4">अपॉइंटमेंट बुक करें</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          अपनी सुविधा के अनुसार ऑनलाइन या ऑफलाइन सत्र बुक करें
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="border-orange-200">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100">
            <CardTitle className="text-xl text-orange-800 flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              बुकिंग फॉर्म
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">पूरा नाम *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                    className="border-orange-200 focus:border-orange-500"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">फोन नंबर *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    required
                    className="border-orange-200 focus:border-orange-500"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="email">ईमेल</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="border-orange-200 focus:border-orange-500"
                />
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>काउंसलर चुनें *</Label>
                  <Select value={formData.counselor} onValueChange={(value) => setFormData({...formData, counselor: value})}>
                    <SelectTrigger className="border-orange-200">
                      <SelectValue placeholder="काउंसलर चुनें" />
                    </SelectTrigger>
                    <SelectContent>
                      {counselors.map((counselor) => (
                        <SelectItem key={counselor} value={counselor}>{counselor}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>सेवा चुनें *</Label>
                  <Select value={formData.service} onValueChange={(value) => setFormData({...formData, service: value})}>
                    <SelectTrigger className="border-orange-200">
                      <SelectValue placeholder="सेवा चुनें" />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((service) => (
                        <SelectItem key={service} value={service}>{service}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label>सत्र का प्रकार *</Label>
                <Select value={formData.mode} onValueChange={(value) => setFormData({...formData, mode: value})}>
                  <SelectTrigger className="border-orange-200">
                    <SelectValue placeholder="सत्र का प्रकार चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="online">ऑनलाइन (Video Call)</SelectItem>
                    <SelectItem value="offline">ऑफलाइन (व्यक्तिगत मुलाकात)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">तारीख *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({...formData, date: e.target.value})}
                    required
                    className="border-orange-200 focus:border-orange-500"
                  />
                </div>
                <div>
                  <Label>समय *</Label>
                  <Select value={formData.time} onValueChange={(value) => setFormData({...formData, time: value})}>
                    <SelectTrigger className="border-orange-200">
                      <SelectValue placeholder="समय चुनें" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>{time}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="message">अतिरिक्त जानकारी</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  placeholder="कोई विशेष आवश्यकता या समस्या के बारे में बताएं..."
                  className="border-orange-200 focus:border-orange-500"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-orange-500 hover:bg-orange-600"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'बुक हो रही है...' : 'अपॉइंटमेंट बुक करें'}
              </Button>
            </form>
          </CardContent>
        </Card>
        
        <div className="space-y-6">
          <Card className="border-orange-200">
            <CardHeader>
              <CardTitle className="text-lg text-orange-800 flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                उपलब्ध समय
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-800">सोमवार - शुक्रवार</h4>
                  <p className="text-gray-600">9:00 AM - 6:00 PM</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800">शनिवार</h4>
                  <p className="text-gray-600">10:00 AM - 4:00 PM</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800">रविवार</h4>
                  <p className="text-gray-600">बंद</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-orange-200">
            <CardHeader>
              <CardTitle className="text-lg text-orange-800 flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                तत्काल सहायता
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4 text-gray-500" />
                  <span className="text-gray-700">8601137822</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <span className="text-gray-700">unmesh.counseling@gmail.com</span>
                </div>
                <p className="text-sm text-gray-600 mt-3">
                  आपातकालीन स्थिति में कृपया तुरंत फोन करें
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AppointmentSection;