import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, Brain, Users, Calendar } from 'lucide-react';

interface HomeSectionProps {
  onSectionChange: (section: string) => void;
}

const HomeSection: React.FC<HomeSectionProps> = ({ onSectionChange }) => {
  const features = [
    {
      icon: Heart,
      title: 'मानसिक स्वास्थ्य',
      description: 'व्यक्तिगत और समूहिक काउंसलिंग सेवाएं',
      action: () => onSectionChange('services')
    },
    {
      icon: Brain,
      title: 'भावनात्मक बुद्धिमत्ता',
      description: 'EQ विकास और प्रशिक्षण कार्यक्रम',
      action: () => onSectionChange('services')
    },
    {
      icon: Users,
      title: 'विशेषज्ञ काउंसलर',
      description: 'अनुभवी और प्रमाणित मनोवैज्ञानिक',
      action: () => onSectionChange('counselors')
    },
    {
      icon: Calendar,
      title: 'आसान बुकिंग',
      description: 'ऑनलाइन और ऑफलाइन अपॉइंटमेंट',
      action: () => onSectionChange('appointment')
    }
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center py-12 bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl">
        <div className="max-w-3xl mx-auto px-6">
          <h1 className="text-4xl md:text-5xl font-bold text-orange-800 mb-4">
            उन्मेष
          </h1>
          <p className="text-xl text-orange-700 mb-2">
            जागृति की ओर एक कदम
          </p>
          <p className="text-lg text-orange-600 mb-8">
            The First Step to Mental Awakening
          </p>
          <p className="text-gray-700 leading-relaxed mb-8">
            उन्मेष का अर्थ है 'आंखों का खुलना' या 'जागृति'। हमारा उद्देश्य है आपकी मानसिक स्वास्थ्य यात्रा में साथ देना और एक स्वस्थ, खुशहाल जीवन की दिशा में आपका मार्गदर्शन करना।
          </p>
          <Button 
            size="lg" 
            className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3"
            onClick={() => onSectionChange('appointment')}
          >
            अभी अपॉइंटमेंट बुक करें
          </Button>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <Card 
              key={index} 
              className="hover:shadow-lg transition-shadow cursor-pointer border-orange-200 hover:border-orange-300"
              onClick={feature.action}
            >
              <CardHeader className="text-center pb-4">
                <div className="mx-auto bg-orange-100 p-3 rounded-full w-fit">
                  <Icon className="h-8 w-8 text-orange-600" />
                </div>
                <CardTitle className="text-lg text-orange-800">
                  {feature.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 text-sm">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default HomeSection;