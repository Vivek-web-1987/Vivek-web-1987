import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, Brain, Users, GraduationCap, Video, MapPin } from 'lucide-react';
import BrochureUpload from '../BrochureUpload';
import RateCardUpload from '../RateCardUpload';

interface ServicesSectionProps {
  onSectionChange: (section: string) => void;
}

const ServicesSection: React.FC<ServicesSectionProps> = ({ onSectionChange }) => {
  const services = [
    {
      icon: Heart,
      title: 'व्यक्तिगत काउंसलिंग',
      description: 'एक-पर-एक व्यक्तिगत सत्र जो आपकी विशिष्ट आवश्यकताओं पर केंद्रित है',
      features: ['तनाव प्रबंधन', 'चिंता और अवसाद', 'आत्मविश्वास निर्माण', 'व्यक्तित्व विकास'],
      duration: '45-60 मिनट',
      mode: ['ऑनलाइन', 'ऑफलाइन']
    },
    {
      icon: Users,
      title: 'समूहिक थेरेपी',
      description: 'समान समस्याओं वाले लोगों के साथ सामूहिक चर्चा और समाधान',
      features: ['सामाजिक कौशल', 'संचार सुधार', 'सहयोग भावना', 'अनुभव साझाकरण'],
      duration: '60-90 मिनट',
      mode: ['ऑनलाइन', 'ऑफलाइन']
    },
    {
      icon: Brain,
      title: 'भावनात्मक बुद्धिमत्ता प्रशिक्षण',
      description: 'EQ विकास के लिए व्यापक कार्यक्रम और कार्यशालाएं',
      features: ['भावना पहचान', 'आत्म-नियंत्रण', 'सामाजिक जागरूकता', 'रिश्ता प्रबंधन'],
      duration: '2-4 घंटे (कार्यशाला)',
      mode: ['ऑनलाइन', 'ऑफलाइन']
    },
    {
      icon: GraduationCap,
      title: 'छात्र और शिक्षक काउंसलिंग',
      description: 'शैक्षणिक संस्थानों के लिए विशेष काउंसलिंग सेवाएं',
      features: ['करियर गाइडेंस', 'परीक्षा तनाव', 'अध्ययन तकनीक', 'शिक्षक सहायता'],
      duration: '30-45 मिनट',
      mode: ['ऑनलाइन', 'ऑफलाइन']
    }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-orange-800 mb-4">हमारी सेवाएं</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          आपकी मानसिक स्वास्थ्य आवश्यकताओं के लिए व्यापक और व्यक्तिगत सेवाएं
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {services.map((service, index) => {
          const Icon = service.icon;
          return (
            <Card key={index} className="border-orange-200 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="bg-orange-100 p-2 rounded-full">
                    <Icon className="h-6 w-6 text-orange-600" />
                  </div>
                  <CardTitle className="text-xl text-orange-800">
                    {service.title}
                  </CardTitle>
                </div>
                <p className="text-gray-600 mt-2">{service.description}</p>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">मुख्य विशेषताएं:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {service.features.map((feature, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs border-orange-200 text-orange-700">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-between text-sm text-gray-600">
                  <div>
                    <span className="font-medium">अवधि: </span>
                    {service.duration}
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  {service.mode.map((mode, idx) => (
                    <Badge key={idx} className="bg-orange-500 hover:bg-orange-600">
                      {mode === 'ऑनलाइन' ? (
                        <><Video className="h-3 w-3 mr-1" />{mode}</>
                      ) : (
                        <><MapPin className="h-3 w-3 mr-1" />{mode}</>
                      )}
                    </Badge>
                  ))}
                </div>
                
                <Button 
                  className="w-full bg-orange-500 hover:bg-orange-600"
                  onClick={() => onSectionChange('appointment')}
                >
                  बुकिंग करें
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      <div className="grid md:grid-cols-2 gap-6">
        <BrochureUpload />
        <RateCardUpload />
      </div>
    </div>
  );
};

export default ServicesSection;