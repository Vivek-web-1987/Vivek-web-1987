import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const ContactSection: React.FC = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "संदेश भेजा गया!",
      description: "हम जल्द ही आपसे संपर्क करेंगे।",
    });
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-orange-800 mb-4">संपर्क करें</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          हमसे जुड़ें और अपने मानसिक स्वास्थ्य की यात्रा शुरू करें
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="border-orange-200">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100">
            <CardTitle className="text-xl text-orange-800 flex items-center">
              <Send className="h-5 w-5 mr-2" />
              संदेश भेजें
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">पूरा नाम *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                  className="border-orange-200 focus:border-orange-500"
                />
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">ईमेल *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    required
                    className="border-orange-200 focus:border-orange-500"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">फोन नंबर</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    className="border-orange-200 focus:border-orange-500"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="subject">विषय *</Label>
                <Input
                  id="subject"
                  value={formData.subject}
                  onChange={(e) => setFormData({...formData, subject: e.target.value})}
                  required
                  className="border-orange-200 focus:border-orange-500"
                  placeholder="आपकी समस्या या प्रश्न का विषय"
                />
              </div>
              
              <div>
                <Label htmlFor="message">संदेश *</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  required
                  className="border-orange-200 focus:border-orange-500 min-h-[120px]"
                  placeholder="कृपया अपना संदेश विस्तार से लिखें..."
                />
              </div>
              
              <Button type="submit" className="w-full bg-orange-500 hover:bg-orange-600">
                संदेश भेजें
              </Button>
            </form>
          </CardContent>
        </Card>
        
        <div className="space-y-6">
          <Card className="border-orange-200">
            <CardHeader>
              <CardTitle className="text-lg text-orange-800">संपर्क विवरण</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-3">
                <Phone className="h-5 w-5 text-orange-600 mt-1" />
                <div>
                  <h4 className="font-semibold text-gray-800">फोन</h4>
                  <p className="text-gray-600">8601137822</p>
                  <p className="text-sm text-gray-500">24/7 आपातकालीन सहायता</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Mail className="h-5 w-5 text-orange-600 mt-1" />
                <div>
                  <h4 className="font-semibold text-gray-800">ईमेल</h4>
                  <p className="text-gray-600">unmesh.counseling@gmail.com</p>
                  <p className="text-sm text-gray-500">24 घंटे में जवाब</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-orange-600 mt-1" />
                <div>
                  <h4 className="font-semibold text-gray-800">पता</h4>
                  <p className="text-gray-600">मानसिक स्वास्थ्य केंद्र<br />उन्मेष काउंसलिंग सेंटर</p>
                  <p className="text-sm text-gray-500">व्यक्तिगत मुलाकात के लिए</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Clock className="h-5 w-5 text-orange-600 mt-1" />
                <div>
                  <h4 className="font-semibold text-gray-800">कार्य समय</h4>
                  <div className="text-gray-600 text-sm space-y-1">
                    <p>सोमवार - शुक्रवार: 9:00 AM - 6:00 PM</p>
                    <p>शनिवार: 10:00 AM - 4:00 PM</p>
                    <p>रविवार: बंद</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ContactSection;