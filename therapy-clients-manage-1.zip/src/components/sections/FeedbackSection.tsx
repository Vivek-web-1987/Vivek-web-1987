import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Star, MessageSquare, ThumbsUp, Award } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const FeedbackSection: React.FC = () => {
  const { toast } = useToast();
  const [rating, setRating] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    service: '',
    counselor: '',
    experience: '',
    feedback: '',
    recommendation: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "फीडबैक सबमिट हो गया!",
      description: "आपकी प्रतिक्रिया के लिए धन्यवाद।",
    });
    setFormData({ name: '', service: '', counselor: '', experience: '', feedback: '', recommendation: '' });
    setRating(0);
  };

  const testimonials = [
    {
      name: "प्रिया शर्मा",
      service: "व्यक्तिगत काउंसलिंग",
      rating: 5,
      feedback: "उन्मेष की सेवाओं से मुझे बहुत मदद मिली। काउंसलर बहुत धैर्यवान और समझदार हैं।"
    },
    {
      name: "राहुल कुमार",
      service: "भावनात्मक बुद्धिमत्ता प्रशिक्षण",
      rating: 5,
      feedback: "EQ ट्रेनिंग के बाद मेरे रिश्तों में सुधार हुआ है। बहुत अच्छा अनुभव रहा।"
    },
    {
      name: "अनिता देवी",
      service: "छात्र काउंसलिंग",
      rating: 4,
      feedback: "मेरे बेटे की परीक्षा की चिंता दूर करने में बहुत सहायक रहे। धन्यवाद!"
    }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-orange-800 mb-4">आपकी प्रतिक्रिया</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          आपका अनुभव हमारे लिए महत्वपूर्ण है। कृपया अपनी प्रतिक्रिया साझा करें।
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="border-orange-200">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100">
            <CardTitle className="text-xl text-orange-800 flex items-center">
              <MessageSquare className="h-5 w-5 mr-2" />
              फीडबैक फॉर्म
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">आपका नाम *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                  className="border-orange-200 focus:border-orange-500"
                />
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>सेवा का प्रकार *</Label>
                  <Select value={formData.service} onValueChange={(value) => setFormData({...formData, service: value})}>
                    <SelectTrigger className="border-orange-200">
                      <SelectValue placeholder="सेवा चुनें" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="personal">व्यक्तिगत काउंसलिंग</SelectItem>
                      <SelectItem value="group">समूहिक थेरेपी</SelectItem>
                      <SelectItem value="eq">भावनात्मक बुद्धिमत्ता प्रशिक्षण</SelectItem>
                      <SelectItem value="student">छात्र काउंसलिंग</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>काउंसलर</Label>
                  <Select value={formData.counselor} onValueChange={(value) => setFormData({...formData, counselor: value})}>
                    <SelectTrigger className="border-orange-200">
                      <SelectValue placeholder="काउंसलर चुनें" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vivek">विवेक कुमार शाही</SelectItem>
                      <SelectItem value="vinod">विनोद कुमार गुप्ता</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label>समग्र रेटिंग *</Label>
                <div className="flex space-x-1 mt-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className={`p-1 ${star <= rating ? 'text-yellow-400' : 'text-gray-300'} hover:text-yellow-400 transition-colors`}
                    >
                      <Star className="h-6 w-6 fill-current" />
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <Label>आपका अनुभव कैसा रहा? *</Label>
                <Select value={formData.experience} onValueChange={(value) => setFormData({...formData, experience: value})}>
                  <SelectTrigger className="border-orange-200">
                    <SelectValue placeholder="अनुभव चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="excellent">उत्कृष्ट</SelectItem>
                    <SelectItem value="good">अच्छा</SelectItem>
                    <SelectItem value="average">औसत</SelectItem>
                    <SelectItem value="poor">खराब</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="feedback">विस्तृत फीडबैक *</Label>
                <Textarea
                  id="feedback"
                  value={formData.feedback}
                  onChange={(e) => setFormData({...formData, feedback: e.target.value})}
                  required
                  className="border-orange-200 focus:border-orange-500 min-h-[100px]"
                  placeholder="कृपया अपना अनुभव विस्तार से बताएं..."
                />
              </div>
              
              <div>
                <Label htmlFor="recommendation">सुझाव</Label>
                <Textarea
                  id="recommendation"
                  value={formData.recommendation}
                  onChange={(e) => setFormData({...formData, recommendation: e.target.value})}
                  className="border-orange-200 focus:border-orange-500"
                  placeholder="हमारी सेवाओं को बेहतर बनाने के लिए सुझाव दें..."
                />
              </div>
              
              <Button type="submit" className="w-full bg-orange-500 hover:bg-orange-600">
                फीडबैक सबमिट करें
              </Button>
            </form>
          </CardContent>
        </Card>
        
        <div className="space-y-6">
          <Card className="border-orange-200">
            <CardHeader>
              <CardTitle className="text-lg text-orange-800 flex items-center">
                <ThumbsUp className="h-5 w-5 mr-2" />
                क्लाइंट समीक्षाएं
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="border-l-4 border-orange-200 pl-4 py-2">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
                    <div className="flex">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-orange-600 mb-2">{testimonial.service}</p>
                  <p className="text-gray-600 text-sm italic">"{testimonial.feedback}"</p>
                </div>
              ))}
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-orange-50 to-orange-100 border-orange-200">
            <CardContent className="p-6 text-center">
              <Award className="h-12 w-12 text-orange-600 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-orange-800 mb-2">आपकी संतुष्टि हमारी प्राथमिकता</h3>
              <p className="text-gray-700 text-sm">
                हम लगातार अपनी सेवाओं को बेहतर बनाने के लिए प्रतिबद्ध हैं। आपकी प्रतिक्रिया हमें बेहतर बनने में मदद करती है।
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default FeedbackSection;