import React from 'react';
import CounselorProfile from '@/components/CounselorProfile';
import BrochureUpload from '@/components/BrochureUpload';

interface CounselorsSectionProps {
  onSectionChange: (section: string) => void;
}

const CounselorsSection: React.FC<CounselorsSectionProps> = ({ onSectionChange }) => {
  const counselors = [
    {
      name: 'डॉ. विवेक कुमार शाही',
      title: 'मुख्य मनोवैज्ञानिक',
      degree: 'Ph.D. in Psychology',
      experience: '8+ वर्ष अनुभव',
      specializations: ['व्यक्तित्व विकास', 'तनाव प्रबंधन', 'रिश्ते की समस्याएं'],
      education: 'M.A. Psychology, Ph.D. Clinical Psychology',
      languages: ['हिंदी', 'English'],
      availability: 'सोमवार - शुक्रवार: 9:00 AM - 6:00 PM'
    },
    {
      name: 'डॉ. तुलिका पांडेय',
      title: 'वरिष्ठ मनोवैज्ञानिक',
      degree: 'Ph.D. in Psychology',
      experience: '8+ वर्ष अनुभव',
      specializations: ['बाल मनोविज्ञान', 'शैक्षणिक तनाव', 'व्यवहार चिकित्सा'],
      education: 'M.A. Psychology, Ph.D. Child Psychology',
      languages: ['हिंदी', 'English'],
      availability: 'सोमवार - शनिवार: 10:00 AM - 5:00 PM'
    },
    {
      name: 'डॉ. क्षमा सिंह',
      title: 'क्लिनिकल साइकोलॉजिस्ट',
      degree: 'Ph.D. in Psychology',
      experience: '7+ वर्ष अनुभव',
      specializations: ['अवसाद चिकित्सा', 'चिंता विकार', 'महिला मानसिक स्वास्थ्य'],
      education: 'M.A. Psychology, Ph.D. Clinical Psychology',
      languages: ['हिंदी', 'English'],
      availability: 'मंगलवार - शनिवार: 9:00 AM - 6:00 PM'
    },
    {
      name: 'डॉ. वेंकट रमन पांडेय',
      title: 'काउंसलिंग साइकोलॉजिस्ट',
      degree: 'Ph.D. in Psychology',
      experience: '8+ वर्ष अनुभव',
      specializations: ['करियर काउंसलिंग', 'युवा मानसिक स्वास्थ्य', 'पारिवारिक चिकित्सा'],
      education: 'M.A. Psychology, Ph.D. Counseling Psychology',
      languages: ['हिंदी', 'English'],
      availability: 'सोमवार - शुक्रवार: 11:00 AM - 7:00 PM'
    },
    {
      name: 'डॉ. बिमलेश कुशवाहा',
      title: 'व्यवहारिक मनोवैज्ञानिक',
      degree: 'Ph.D. in Psychology',
      experience: '6+ वर्ष अनुभव',
      specializations: ['व्यवहार संशोधन', 'तनाव प्रबंधन', 'छात्र काउंसलिंग'],
      education: 'M.A. Psychology, Ph.D. Behavioral Psychology',
      languages: ['हिंदी', 'English'],
      availability: 'सोमवार - शनिवार: 10:00 AM - 6:00 PM'
    },
    {
      name: 'डॉ. अपर्णा पाठक',
      title: 'मनोवैज्ञानिक',
      degree: 'Ph.D. in Psychology',
      experience: '8+ वर्ष अनुभव',
      specializations: ['मानसिक स्वास्थ्य', 'व्यक्तित्व विकार', 'पारिवारिक परामर्श'],
      education: 'M.A. Psychology, Ph.D. Clinical Psychology',
      languages: ['हिंदी', 'English'],
      availability: 'सोमवार - शुक्रवार: 10:00 AM - 5:00 PM'
    },
    {
      name: 'डॉ. विकास रंजन मणि त्रिपाठी',
      title: 'एडिक्शन स्पेशलिस्ट',
      degree: 'Ph.D. in Psychology',
      experience: '8+ वर्ष अनुभव',
      specializations: ['मोबाइल एडिक्शन', 'गेम एडिक्शन', 'पेरेंटिंग काउंसलिंग'],
      education: 'Ph.D. Psychology, Addiction Counseling Certification',
      languages: ['हिंदी', 'English'],
      availability: 'सोमवार - शुक्रवार: 2:00 PM - 8:00 PM'
    },
    {
      name: 'डॉ. विनोद कुमार गुप्ता',
      title: 'सीनियर काउंसलर',
      degree: 'Ph.D. in Psychology',
      experience: '8+ वर्ष अनुभव',
      specializations: ['पारिवारिक परामर्श', 'वैवाहिक समस्याएं', 'व्यक्तित्व विकास'],
      education: 'Ph.D. Psychology, Family Therapy Certification',
      languages: ['हिंदी', 'English'],
      availability: 'मंगलवार - शनिवार: 11:00 AM - 6:00 PM'
    }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-orange-800 mb-4">हमारे विशेषज्ञ काउंसलर</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          अनुभवी और प्रमाणित मनोवैज्ञानिकों से मिलें जो आपकी मानसिक स्वास्थ्य यात्रा में आपका साथ देंगे।
        </p>
      </div>

      <div className="mb-8">
        <BrochureUpload />
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {counselors.map((counselor, index) => (
          <CounselorProfile
            key={index}
            counselor={counselor}
            index={index}
            onSectionChange={onSectionChange}
          />
        ))}
      </div>
    </div>
  );
};

export default CounselorsSection;