import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { X, Home, Calendar, Users, BookOpen, Phone, MessageCircle } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentSection: string;
  onSectionChange: (section: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, currentSection, onSectionChange }) => {
  const menuItems = [
    { id: 'home', label: 'मुख्य पृष्ठ', icon: Home },
    { id: 'appointment', label: 'अपॉइंटमेंट', icon: Calendar },
    { id: 'counselors', label: 'काउंसलर', icon: Users },
    { id: 'services', label: 'सेवाएं', icon: BookOpen },
    { id: 'contact', label: 'संपर्क', icon: Phone },
    { id: 'feedback', label: 'फीडबैक', icon: MessageCircle },
  ];

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={onClose} />
      )}
      
      <div className={`fixed left-0 top-0 h-full w-64 bg-white shadow-xl transform transition-transform duration-300 z-50 ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } md:relative md:translate-x-0`}>
        <div className="p-4 border-b border-orange-100">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-orange-800">मेन्यू</h2>
            <Button variant="ghost" size="icon" onClick={onClose} className="md:hidden">
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        <nav className="p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={currentSection === item.id ? 'default' : 'ghost'}
                className={`w-full justify-start text-left ${
                  currentSection === item.id 
                    ? 'bg-orange-500 text-white hover:bg-orange-600' 
                    : 'text-gray-700 hover:bg-orange-50'
                }`}
                onClick={() => {
                  onSectionChange(item.id);
                  onClose();
                }}
              >
                <Icon className="h-5 w-5 mr-3" />
                {item.label}
              </Button>
            );
          })}
        </nav>
      </div>
    </>
  );
};

export default Sidebar;