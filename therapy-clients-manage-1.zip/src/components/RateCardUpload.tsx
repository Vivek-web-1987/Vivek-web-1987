import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Upload, FileText, Download, DollarSign } from 'lucide-react';
import FileUpload from './FileUpload';
import { useToast } from '@/hooks/use-toast';

const RateCardUpload: React.FC = () => {
  const [rateCardFile, setRateCardFile] = useState('');
  const [rateCardFileName, setRateCardFileName] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const handleRateCardUpload = (url: string, fileName: string) => {
    setRateCardFile(url);
    setRateCardFileName(fileName);
    if (url) {
      toast({
        title: 'Success',
        description: 'Rate card uploaded successfully',
      });
      setIsDialogOpen(false);
    }
  };

  const handleDownload = () => {
    if (rateCardFile) {
      window.open(rateCardFile, '_blank');
    }
  };

  return (
    <Card className="border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
      <CardHeader>
        <CardTitle className="text-xl text-green-800 text-center flex items-center justify-center space-x-2">
          <DollarSign className="h-5 w-5" />
          <span>विशेष पैकेज रेट कार्ड</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {rateCardFileName ? (
          <div className="space-y-3">
            <div className="flex items-center justify-center space-x-2 p-3 bg-green-50 rounded-lg">
              <FileText className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium text-green-700">
                {rateCardFileName}
              </span>
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={handleDownload}
                className="flex-1 bg-green-500 hover:bg-green-600"
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="flex-1">
                    <Upload className="h-4 w-4 mr-2" />
                    Update
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Update Rate Card</DialogTitle>
                  </DialogHeader>
                  <FileUpload
                    onFileUploaded={handleRateCardUpload}
                    acceptedTypes=".pdf,.jpg,.jpeg,.png"
                    maxSize={10 * 1024 * 1024}
                    label="Rate Card File"
                    currentFile={rateCardFileName}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </div>
        ) : (
          <div className="text-center space-y-3">
            <p className="text-gray-600 text-sm">
              विशेष पैकेज की दरों का कार्ड अपलोड करें
            </p>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-green-500 hover:bg-green-600">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Rate Card
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Upload Rate Card</DialogTitle>
                </DialogHeader>
                <FileUpload
                  onFileUploaded={handleRateCardUpload}
                  acceptedTypes=".pdf,.jpg,.jpeg,.png"
                  maxSize={10 * 1024 * 1024}
                  label="Rate Card File"
                />
              </DialogContent>
            </Dialog>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RateCardUpload;