import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Upload, FileText, Download } from 'lucide-react';
import FileUpload from './FileUpload';
import { useToast } from '@/hooks/use-toast';

const BrochureUpload: React.FC = () => {
  const [brochureFile, setBrochureFile] = useState('');
  const [brochureFileName, setBrochureFileName] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const handleBrochureUpload = (url: string, fileName: string) => {
    setBrochureFile(url);
    setBrochureFileName(fileName);
    if (url) {
      toast({
        title: 'Success',
        description: 'Unmesh brochure uploaded successfully',
      });
      setIsDialogOpen(false);
    }
  };

  const handleDownload = () => {
    if (brochureFile) {
      window.open(brochureFile, '_blank');
    }
  };

  return (
    <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
      <CardHeader>
        <CardTitle className="text-xl text-blue-800 text-center">
          Unmesh Brochure
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {brochureFileName ? (
          <div className="space-y-3">
            <div className="flex items-center justify-center space-x-2 p-3 bg-green-50 rounded-lg">
              <FileText className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium text-green-700">
                {brochureFileName}
              </span>
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={handleDownload}
                className="flex-1 bg-blue-500 hover:bg-blue-600"
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="flex-1">
                    <Upload className="h-4 w-4 mr-2" />
                    Update
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Update Unmesh Brochure</DialogTitle>
                  </DialogHeader>
                  <FileUpload
                    onFileUploaded={handleBrochureUpload}
                    acceptedTypes=".pdf,.jpg,.jpeg,.png"
                    maxSize={10 * 1024 * 1024}
                    label="Brochure File"
                    currentFile={brochureFileName}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </div>
        ) : (
          <div className="text-center space-y-3">
            <p className="text-gray-600 text-sm">
              Upload Unmesh organization brochure
            </p>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-500 hover:bg-blue-600">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Brochure
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Upload Unmesh Brochure</DialogTitle>
                </DialogHeader>
                <FileUpload
                  onFileUploaded={handleBrochureUpload}
                  acceptedTypes=".pdf,.jpg,.jpeg,.png"
                  maxSize={10 * 1024 * 1024}
                  label="Brochure File"
                />
              </DialogContent>
            </Dialog>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default BrochureUpload;