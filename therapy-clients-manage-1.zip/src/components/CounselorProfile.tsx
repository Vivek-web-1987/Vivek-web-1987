import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Award, Clock, Upload } from 'lucide-react';
import CVUploadManager from './CVUploadManager';

interface Counselor {
  name: string;
  title: string;
  degree: string;
  experience: string;
  specializations: string[];
  education: string;
  languages: string[];
  availability: string;
}

interface CounselorProfileProps {
  counselor: Counselor;
  index: number;
  onSectionChange: (section: string) => void;
}

const CounselorProfile: React.FC<CounselorProfileProps> = ({ counselor, index, onSectionChange }) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleCVSaved = () => {
    setIsDialogOpen(false);
  };

  return (
    <Card className="border-orange-200 hover:shadow-lg transition-shadow">
      <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100">
        <div className="text-center">
          <CardTitle className="text-lg text-orange-800 mb-1">
            {counselor.name}
          </CardTitle>
          <p className="text-orange-600 font-medium text-sm">{counselor.title}</p>
          <Badge className="mt-2 bg-orange-500 text-white">{counselor.degree}</Badge>
          <div className="flex items-center justify-center mt-2 text-sm text-gray-600">
            <Award className="h-4 w-4 mr-1" />
            {counselor.experience}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3 pt-4">
        <div>
          <h4 className="font-semibold text-gray-800 mb-2 text-sm">विशेषज्ञता:</h4>
          <div className="flex flex-wrap gap-1">
            {counselor.specializations.map((spec, idx) => (
              <Badge key={idx} variant="secondary" className="bg-orange-100 text-orange-800 text-xs">
                {spec}
              </Badge>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="font-semibold text-gray-800 mb-1 text-sm">भाषाएं:</h4>
          <p className="text-xs text-gray-600">{counselor.languages.join(', ')}</p>
        </div>
        
        <div className="flex items-start space-x-2">
          <Clock className="h-3 w-3 text-gray-500 mt-0.5" />
          <div>
            <h4 className="font-semibold text-gray-800 text-xs">उपलब्धता:</h4>
            <p className="text-xs text-gray-600">{counselor.availability}</p>
          </div>
        </div>

        <div className="space-y-2">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full text-sm">
                <Upload className="h-4 w-4 mr-2" />
                CV Upload/Edit
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>{counselor.name} - CV Management</DialogTitle>
              </DialogHeader>
              <CVUploadManager
                counselorName={counselor.name}
                onCVSaved={handleCVSaved}
              />
            </DialogContent>
          </Dialog>
          
          <Button 
            className="w-full bg-orange-500 hover:bg-orange-600 text-sm"
            onClick={() => onSectionChange('appointment')}
          >
            अपॉइंटमेंट बुक करें
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CounselorProfile;