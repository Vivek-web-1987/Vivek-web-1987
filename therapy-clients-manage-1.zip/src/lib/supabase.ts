import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://wwqqxdvwxsrcgdjbwsxe.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind3cXF4ZHZ3eHNyY2dkamJ3c3hlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA3NDA2MjQsImV4cCI6MjA2NjMxNjYyNH0.61lbYm8-8oUWx99Bm8-R_4ltEmMhkH6aFgnOg3E5PTw';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };