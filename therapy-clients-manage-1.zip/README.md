# उन्मेष - Unmesh Counseling App

**जागृति की ओर एक कदम** | *The First Step to Mental Awakening*

## About
उन्मेष is a comprehensive mental health and counseling application designed to provide accessible psychological support and emotional intelligence training.

## Features
- 📱 **Bilingual Interface** - Hindi & English support
- 👨‍⚕️ **Professional Counselors** - Qualified mental health professionals
- 📅 **Appointment Booking** - Easy scheduling system
- 🧠 **Emotional Intelligence Training** - Self-improvement modules
- 💬 **Online & Offline Counseling** - Flexible consultation options
- 📞 **24/7 Support** - Emergency contact available

## Counselors
- **Vivek Kumar Shahi** - Lead Counselor
- **Vinod Kumar Gupta** - Senior Counselor (8601137822)

## Services
- Individual Counseling
- Group Therapy Sessions
- Student & Faculty Counseling
- Emotional Intelligence Training
- Crisis Intervention
- Mental Health Workshops

## Technology Stack
- **Frontend**: React + TypeScript + Tailwind CSS
- **Mobile**: Capacitor (Android/iOS)
- **UI Components**: Radix UI + shadcn/ui
- **Build Tool**: Vite

## Development

### Prerequisites
- Node.js 18+
- Android Studio (for Android builds)
- Xcode (for iOS builds)

### Installation
```bash
npm install
```

### Development Server
```bash
npm run dev
```

### Build for Production
```bash
npm run build
```

### Mobile Development

#### Android
```bash
# Build and sync
npm run build:android

# Run on Android device/emulator
npm run android
```

#### iOS
```bash
# Sync with iOS
npx cap sync ios

# Open in Xcode
npx cap open ios
```

## Play Store Deployment

### Prerequisites
1. Google Play Console account
2. App signing key
3. Completed app content rating
4. Privacy policy URL

### Build Release APK
```bash
# Build production version
npm run build

# Sync with Android
npx cap sync android

# Open Android Studio
npx cap open android

# In Android Studio:
# Build > Generate Signed Bundle/APK
# Select Android App Bundle (recommended)
# Sign with your keystore
```

### App Store Information
- **Package Name**: `com.unmesh.counseling`
- **App Name**: उन्मेष - Unmesh Counseling
- **Version**: 1.0.0
- **Category**: Health & Fitness / Medical
- **Content Rating**: Everyone

## Contact
For support and inquiries:
- **Phone**: 8601137822
- **Email**: Contact through the app

## License
Private - All rights reserved

---
*उन्मेष - जागृति की ओर एक कदम*