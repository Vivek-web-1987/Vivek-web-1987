# Play Store Deployment Guide for उन्मेष App

## Quick Setup Steps

### 1. Install Dependencies
```bash
npm install
npm install @capacitor/cli @capacitor/core @capacitor/android
```

### 2. Build & Initialize
```bash
npm run build
npx cap init "उन्मेष - Unmesh Counseling" "com.unmesh.counseling"
npx cap add android
```

### 3. Sync & Build
```bash
npx cap sync android
npx cap open android
```

### 4. Android Studio Steps
1. Open project in Android Studio
2. Build > Generate Signed Bundle/APK
3. Create keystore if needed
4. Select "Android App Bundle" (AAB)
5. Sign and build

### 5. Play Console Upload
1. Create Google Play Console account
2. Create new app: "उन्मेष - Unmesh Counseling"
3. Upload AAB file
4. Complete store listing:
   - Title: उन्मेष - Unmesh Counseling
   - Description: Mental health counseling app
   - Category: Health & Fitness
   - Content rating: Everyone
5. Add screenshots and privacy policy
6. Submit for review

## App Details
- **Package**: com.unmesh.counseling
- **Version**: 1.0.0
- **Theme**: Saffron/Orange
- **Languages**: Hindi + English

## Ready for Play Store! 🚀