package com.unmesh.counseling;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
